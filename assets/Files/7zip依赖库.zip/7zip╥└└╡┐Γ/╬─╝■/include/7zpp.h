#pragma once


#include "SevenZipCompressor.h"
#include "SevenZipExtractor.h"
#include "SevenZipLister.h"

// Version of this library
#define SEVENZIP_VERSION L"0.3.0.20180422"
#define SEVENZIP_BRANCH L"master"

